var express = require('express');
var Client = require('node-rest-client').Client;
var client = new Client();
var router = express.Router();

/* GET home page. */
router.post('/gatling', function(req, res, next) {

  console.log(req.body)

  var args = {
    data: {"branch": "master","content": "["+req.body +"]", "commit_message": "CQ:1087 Curl Updates file"},
    headers: { "Content-Type": "application/json"  , "PRIVATE-TOKEN": "VQtT2w4suWM6wnD3m6qt"}
  };

  client.put("https://code.tiamat.cloud/api/v4/projects/159/repository/files/%2Fsrc%2Fgatling%2Fresources%2Fdata%2Finput-gamekeeper%2Ejson?ref=master", args, function (data, response) {
    // parsed response body as js object
    console.log(data);
    // raw response
    //console.log(response);
  }).on('error', function (err) {
    console.log('something went wrong on the request', err.request.options);
  });

  res.status(200);
  res.send('Task is about to start');

});

module.exports = router;
